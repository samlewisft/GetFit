//
//  Exercise.swift
//  GetFit
//
//  Created by Samuel Lewis on 18/02/2015.
//  Copyright (c) 2015 Samuel Lewis. All rights reserved.
//

import Foundation

struct Exercise {
    let exerciseCategory : String
    let name : String
    let desc : String
    let imageName : String
    let imageNameTwo : String
    let Wallpaper : String
}